from .Main import main

def run_app():
    main()
    
if __name__ == "__main__":
    main()